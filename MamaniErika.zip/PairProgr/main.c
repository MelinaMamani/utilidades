#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"

/****************************************************
    Menu:
        1. Parse del archivo data.csv
        2. Calculo
        3. Generar archivo
*****************************************************/


int main()
{
    char seguir = 's';
    Employee* lista = employee_new();
    ArrayList* arrayList = al_newArrayList();

    do{
        switch(menu()){

        case 1:
            if(parserEmployee(arrayList)){
                    printf("Empleados parseados. \n\n");
            }
            employee_print(lista, arrayList);
            break;

        case 2:
            employee_calculate(lista,arrayList);
            //al_map(arrayList, employee_calculate);

        case 3:
            if(save_employees(arrayList)==0){
                    printf("Empleados guardados. \n\n");
            }
            break;

        case 4:
            seguir = 'n';
            break;
        }
    }while(seguir == 's');
    return 0;
}
