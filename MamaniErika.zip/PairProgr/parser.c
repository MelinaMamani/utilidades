#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"

int parserEmployee(ArrayList* pArrayListEmployee)
{
    char var1[10], var2[51], var3[30];
    int cant;

    FILE* pFile= fopen("data2.csv", "r");

    if((pFile)==NULL){
        printf("No se pudo abrir el archivo.\n");
    }

    fscanf(pFile, "%[^,],%[^,],%[^\n]\n", var1, var2, var3);

    while(!feof(pFile)){


            cant = fscanf(pFile,"%[^,],%[^,],%[^\n]\n", var1, var2, var3);

            if(cant!=3){
                if(feof(pFile)){
                    break;
                }
                else{
                    printf("Error.\n");
                    exit(EXIT_FAILURE);
                }
            }


            Employee* eAux = employee_new();

            //printf("id %s\n", var1);
            employee_setId(eAux,atoi(var1));
            //printf("name %s\n", var2);
            employee_setName(eAux,var2);
            //printf("horas %s\n", var3);
            employee_setHoras(eAux,atoi(var3));
            pArrayListEmployee->add(pArrayListEmployee,eAux);
        }

    fclose(pFile);

    return 0;
}

