#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"

int menu(){
    int opcion;

    printf("Menu Empleados:\n");
    printf("1. Parse del archivo data.csv\n");
    printf("2. Calculo\n");
    printf("3. Generar archivo\n");
    printf("4. Salir\n");

    printf("\nIngrese una opcion: ");
    scanf("%d", &opcion);

    return opcion;
    system("cls");
}

void employee_calculate(Employee* E1, ArrayList* arrayList)
{
    int i;
    int pause = 1;
    float returnAux;

    for(i=0; i<arrayList->len(arrayList);i++)
    {
        E1 = arrayList->get(arrayList,i);

        if(employee_getHoras(E1)>0 && employee_getHoras(E1)<= 176)
        {
            returnAux = employee_getHoras(E1) * 180;
            employee_setSueldo(E1, returnAux);
        }
        else if(employee_getHoras(E1)>=177 && employee_getHoras(E1)<=208)
        {
            returnAux = employee_getHoras(E1)* 270;
            employee_setSueldo(E1, returnAux);
        }
        else if(employee_getHoras(E1)>=209 && employee_getHoras(E1)<=240)
        {
            returnAux = employee_getHoras(E1)* 360;
            employee_setSueldo(E1, returnAux);
        }
    }
    xlkCenterPrintf("LISTA DE EMPLEADOS",1);

    xlkSortPrintf(1,"%s,%s,%s,%s",4,"ID EMPLEADO","NOMBRE","HORAS","SUELDO");

            for( i=0;i <arrayList->len(arrayList);i++ )
            {
                E1 = arrayList->get(arrayList,i);
                xlkSortPrintf(4,"%d,%s,%d,%f",4,employee_getId(E1), employee_getName(E1), employee_getHoras(E1),employee_getSueldo(E1));

                if( i == 125*pause)
                {
                    system("pause");
                    pause++;
                }
            }
}

/*void employee_calculate(void* EA)
{
    Employee* E1 = (Employee*) EA;
    float sueldo;

    if(employee_getHoras(E1)==1)
    {
        sueldo = employee_getHoras(E1)* 180;
        employee_setSueldo(E1, sueldo);
    }
    else if(employee_getHoras(E1)==0)
    {
        sueldo = employee_getHoras(E1)* 270;
        employee_setSueldo(E1, sueldo);
    }
    else if(employee_getHoras(E1)==-1)
    {
        sueldo = employee_getHoras(E1)* 360;
        employee_setSueldo(E1, sueldo);
    }
}*/

void one_employee_print(Employee* this)
{
    if(this !=NULL)
    {
        xlkSortPrintf(3,"%d,%s,%d",3,employee_getId(this), employee_getName(this), employee_getHoras(this));
    }
}

void employee_print(Employee* this, ArrayList* arrayList)
{
    int i, pause = 1;

    xlkCenterPrintf("LISTA DE EMPLEADOS",1);

    xlkSortPrintf(1,"%s,%s,%s",3,"ID EMPLEADO","NOMBRE","HORAS");

            for( i=0;i <arrayList->len(arrayList);i++ )
            {
                this = arrayList->get(arrayList,i);
                xlkSortPrintf(3,"%d,%s,%d",3,employee_getId(this), employee_getName(this), employee_getHoras(this));

                if( i == 125*pause)
                {
                    system("pause");
                    pause++;
                }
            }
}

int getInt(int* input,char message[],char eMessage[], int lowLimit, int hiLimit)
{
    int indice = 0;

    printf("%s",message);
    scanf("%d",input);

    while( *input < lowLimit || *input >hiLimit)
    {
        printf("%s", eMessage);
        scanf("%d",input);
    }

    if(*input >lowLimit || *input <hiLimit){
        return indice;
    }
    else{
        indice = -1;
        return indice;
    }
}

int save_employees(ArrayList* arrayList)
{
    FILE* f;

    Employee* employee = employee_new();

    int returnAux = -1;
    int i;

    if(arrayList != NULL)
    {
        f = fopen("info.csv", "w");
        if(f != NULL)
        {
            fprintf(f,"id,name,horasTrabajadas,sueldo\n");
            for(i=0; i<arrayList->len(arrayList); i++)
            {

                employee = arrayList->get(arrayList,i);

                fprintf(f,"%d,%s,%d,%.2f\n",employee_getId(employee),employee_getName(employee),employee_getHoras(employee),employee_getSueldo(employee));

            }

             fclose(f);

            /*for(i=0;i<arrayList->len(arrayList);i++)
            {
                  employee = arrayList->get(arrayList,i);
                  free(employee);
            }

            arrayList->deleteArrayList(arrayList);*/
        }
        returnAux = 0;
    }

    return returnAux;

}

Employee* employee_new(void)
{
    Employee* this = (Employee*) malloc(sizeof(Employee));

    return this;

}

void employee_delete(Employee* this)
{
    free(this);
}

void employee_setId(Employee* this, int id)
{
    if(id > 0)
        this->id = id;
}

int employee_getId(Employee* this)
{
    return this->id;
}

void employee_setName(Employee* this, char* name)
{
    if(strlen(name)<=51)
        strcpy(this->name, name);
}

char* employee_getName(Employee* this)
{
    return this->name;
}

void employee_setHoras(Employee* this, int horas)
{
    if(horas > 0)
        this->horas = horas;
}

int employee_getHoras(Employee* this)
{
    return this->horas;
}

void employee_setSueldo(Employee* this, float sueldo)
{
    if(sueldo > 0)
        this->sueldo = sueldo;
}

float employee_getSueldo(Employee* this)
{
    return this->sueldo;
}

void employee_setIsEmpty(Employee* this, char* isEmpty)
{
    if(strcmp(isEmpty, "true")==0){
        this->isEmpty = 1;
    }
    else if(strcmp(isEmpty, "false")==0){
        this->isEmpty = 0;
    }
}

int employee_getIsEmpty(Employee* this)
{
    return this->isEmpty;
}


